﻿#include "stdafx.h"
#include "In.h"

 int errorLines, errorPos;
 bool readFailed = false;
 int failedFileSize = -1;
using namespace std;

namespace In
{

	IN getin(wchar_t infile[])
	{
		setlocale(LC_ALL, "russian");
		IN in;
		in.size = 0, in.lines = 1, in.ignor = 0;
		int pos =1;

		unsigned char* filetext = new unsigned char[IN_MAX_LEN_TEXT];
		std::ifstream file(infile);
		if (!file.is_open())
		{
			throw ERROR_THROW(110);
		}
		while (in.size < IN_MAX_LEN_TEXT)
		{
			char symbol;
			unsigned char unsignedSymbol;
			file.get(symbol);

			unsignedSymbol = symbol;
			if (file.eof())
			{
				filetext[in.size] = '\0';
				break;
			}
			switch (in.code[unsignedSymbol])
			{
			case in.T:
			{
				filetext[in.size] = unsignedSymbol;
				in.size++;
				pos++;
				break;
			}
			case in.F:
			{
				readFailed = true;
				errorLines = in.lines;
				errorPos = pos;
				in.text = filetext;
				failedFileSize = in.size;
				return in;
				break;
			}
			case in.I:
			{
				in.ignor++;
				pos++;
				break;
			}
			default:
			{
				filetext[in.size] = in.code[unsignedSymbol];
				in.size++;
				pos++;
				break;
			}
			}
			if (unsignedSymbol == IN_CODE_ENDL)
			{
				in.lines++;
				pos = 1;
			}
			
		}
		in.text = filetext;
		return in;
	}
}