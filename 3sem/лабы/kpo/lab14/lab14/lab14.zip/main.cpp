#include "stdafx.h"

#include "Error.h"
#include "In.h"
#include "Log.h"
#include "Parm.h"

extern int errorLines, errorPos;
extern bool readFailed;
int _tmain(int argc, _TCHAR* argv[])
{
	
	setlocale(LC_ALL, "russian");
	try
	{
		Parm::PARM parm = Parm::getparm(argc, argv);
		std::wcout << "-in:" << parm.in << ", -out:" << parm.out << ", -log:" << parm.log << std::endl;
	}
	catch (Error::ERROR e)
	{
		std::cout << "������ " << e.id << ": " << e.message << std::endl;
		return 0;
	}
	Parm::PARM parm = Parm::getparm(argc, argv);

	try
	{
		Parm::PARM parm = Parm::getparm(argc, argv);
		In::IN in = In::getin(parm.in);
		Out::writeOutFile(Out::getOut(parm.out), in);
		if (readFailed == true)
		{
			throw ERROR_THROW_IN(111, errorLines, errorPos);
		}
		cout << in.text << endl;
		cout << "����� ��������: " << in.size << endl;
		cout << "����� �����: " << in.lines << endl;
		cout << "���������: " << in.ignor << endl;
	}
	catch (Error::ERROR e)
	{
		Out::writeOutError(Out::getOut(parm.out), e);
		std::cout << "������ " << e.id << ": " << e.message << std::endl;
	};
	
	Log::LOG log = Log::INITLOG;
	try
	{
		Parm::PARM parm = Parm::getparm(argc, argv);
		log = Log::getlog(parm.log);
		Log::WriteLine(log, (char*)"����:", (char*)" ��� ������ \n", "");
		Log::WriteLine(log, (wchar_t*)L"����:", (wchar_t*)L" ��� ������ \n", L"");
		Log::WriteLog(log);
	    Log::WriteParm(log,parm);
		In::IN in = In::getin(parm.in);
		Log::WriteIn(log, in);
		Log::Close(log);
	}
	catch (Error::ERROR e)
	{
		Log::WriteError(log, e);
	};


	return 0;
};	