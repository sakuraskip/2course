﻿namespace lab14
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Threads.task3(100);//простые числа от 1 до n
            //Threads.task4(15);//одно четное другое нечетное
            //Threads.task5();//таймер
            Threads.task4_1_1(15);//сначала четные потом нечетные
        }
    }
}
