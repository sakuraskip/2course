﻿namespace lab15
{
    public class Program
    {
        async static Task Main(string[] args)
        {
            //Tpl.task1(); //умножение вектора на число
            //Tpl.task3(); //3 задачи с возвратом результата
            //Tpl.task4_1();// continueWith
            //await Tpl.task4_2(321);// get awaiter

            //Parallel1.task5();// параллельный for
            //Parallel1.task6();// parallel invoke
            //Console.WriteLine();
            Tpl.task7(); // магаз


             //Parallel1.task8_1();
        }
    }
}
