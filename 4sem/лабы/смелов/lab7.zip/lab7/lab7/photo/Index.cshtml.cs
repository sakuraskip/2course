using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace lab7.photo
{
    public class IndexModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
